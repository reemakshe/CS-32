#include "Actor.h"
#include "StudentWorld.h"

Actor::Actor(int imageID, int x, int y, Direction dir, int depth, StudentWorld* studWorld)
: GraphObject(imageID, x, y, dir, depth)
{
    m_alive = true;
    m_studWorld = studWorld;
}

void Actor::doSomething()
{}

bool Actor::isDead()
{
    return !m_alive;
}

void Actor::setAliveStatus(bool set)
{
    m_alive = set;
}

StudentWorld* Actor::getWorld()
{
    return m_studWorld;
}

Actor::~Actor()
{}

Socrates::Socrates(StudentWorld* studWorld)
: Actor(IID_PLAYER, 0, 128, 0, 0, studWorld)
{
    positionalAngle = 180;
    m_hp = 0;
}

void Socrates::doSomething()
{
    if (isDead())
        return;
    int ch;
    if (getWorld()->getKey(ch))
    {
        double x = getX();
        double y = getY();
        double PI = 3.14159;
        double newAngle;

        switch (ch)
        {
            case KEY_PRESS_LEFT:
                newAngle = (positionalAngle + 5) * (PI / 180);
                positionalAngle += 5;
                x = VIEW_RADIUS * (cos(newAngle));
                y = VIEW_RADIUS * (sin(newAngle));
                x = (VIEW_WIDTH / 2) + x;
                y = (VIEW_WIDTH / 2) + y;
                moveTo(x, y);
                setDirection(positionalAngle + 185);
                break;
            case KEY_PRESS_RIGHT:
                newAngle = (positionalAngle - 5) * (PI / 180);
                positionalAngle -= 5;
                x = VIEW_RADIUS * (cos(newAngle));
                y = VIEW_RADIUS * (sin(newAngle));
                x = (VIEW_HEIGHT / 2) + x;
                y = (VIEW_HEIGHT / 2) + y;
                moveTo(x, y);
                setDirection(positionalAngle + 185);
                break;
        }

    }

}

int Socrates::getHealth()
{
    return m_hp;
}

Socrates::~Socrates()
{}

DirtPile::DirtPile(int x, int y, StudentWorld* studWorld)
: Actor(IID_DIRT, x, y, 0, 1, studWorld)
{}

void DirtPile::doSomething()
{}

DirtPile::~DirtPile()
{}





