#include "StudentWorld.h"
#include "GameConstants.h"
#include <string>
#include <sstream>
#include <iomanip>

using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
    return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath)
{
}

int StudentWorld::init()
{
    m_socrates = new Socrates(this);

    int end = max(180 - 20 * getLevel(), 20);

    double x;
    double y;
    double radius;

    for (int i = 0; i < end; i++)
    {
        
        x = randInt(0, VIEW_WIDTH);
        y = randInt(0, VIEW_HEIGHT);
        
        radius = sqrt(pow(x - (VIEW_WIDTH / 2), 2) + pow(y - (VIEW_HEIGHT / 2), 2));
        
        if (!(radius <= 120))
        {
            i--;
            continue;
        }
        

        m_actors.push_back(new DirtPile(x, y, this));
    }

    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    m_socrates->doSomething();

    list<Actor*>:: iterator it = m_actors.begin();

    while (it != m_actors.end())
    {
        (*it)->doSomething();

        if (m_socrates->isDead())
        {
            decLives();
            return GWSTATUS_PLAYER_DIED;
        }

        it++;


    }

    it = m_actors.begin();

    while (it != m_actors.end())
    {
        if ((*it)->isDead())
        {
            delete *it;
            list<Actor*>::iterator tempIt = it;
            it--;
            m_actors.erase(tempIt);
        }
        else
            it++;
    }

    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    std::list<Actor*>::iterator it = m_actors.begin();

    while (it != m_actors.end())
    {
        delete *it;
        m_actors.erase(it);
        it++;
    }
}

StudentWorld::~StudentWorld()
{
    cleanUp();
}

