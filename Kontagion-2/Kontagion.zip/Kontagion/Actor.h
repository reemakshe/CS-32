
#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

#include "GraphObject.h"
#include "GameWorld.h"
#include <list>
#include <string>

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class StudentWorld;

class Actor : public GraphObject
{
  public:
    Actor(int imageID, int x, int y, Direction dir, int depth, StudentWorld* studWorld);
    virtual void doSomething();
    bool isDead();
    void setAliveStatus(bool set);
    StudentWorld* getWorld();
    virtual ~Actor();
  private:
    bool m_alive;
    StudentWorld* m_studWorld;
};

class Socrates : public Actor
{
  public:
    Socrates(StudentWorld* studWorld);
    virtual void doSomething();
    int getHealth();
    virtual ~Socrates();
  private:
    int m_hp;
    double positionalAngle;
};

class DirtPile : public Actor
{
  public:
    DirtPile(int x, int y, StudentWorld* studWorld);
    virtual void doSomething();
    virtual ~DirtPile();

};


#endif // ACTOR_H_



